import sys
import json
import pymongo
import os
import timeit
import multiprocessing as mlp
from PySide2 import QtCore, QtWidgets, QtGui
from GUI import Ui_MainWindow

client = pymongo.MongoClient('localhost', 27017)
db = client['DateBase']  
coll = db['Row']  
coll.create_index('Nick')
coll.create_index('Phone')
coll.create_index('Surname')


def CreateDick(num, name, fname, phone, uid, nick, wo):
    return {
        'Number': num,
        'Name': name,
        'Surname': fname,
        'Phone': phone,
        'UID': uid,
        'Nick': nick,
        'WO': wo
    }


def UpdateData(id, update_data):
    coll.update_one(id, {'$set': update_data})


def LoadData(collection, data_dict):
    return collection.insert_one(data_dict).inserted_id


def FoundData(collection, elem_dict, combo_mult=0, limit=100):
    return collection.find(elem_dict).skip(combo_mult * 100).limit(limit)


def DeleteData(collection, id):
    collection.delete_one(id)


class MyWin(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(MyWin, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.actionOpen.triggered.connect(self.OpenData)  
        self.ui.actionSave.triggered.connect(self.SaveData)  
        self.ui.actionLoad.triggered.connect(self.LoadData)  
        self.ui.actionEnter_row.triggered.connect(self.ClearRow_forEnter)  
        self.ui.actionSave_row.triggered.connect(self.SaveRow_inDB)  
        self.ui.actionSave_row.setDisabled(True)
        self.ui.actionRemove_data_row.triggered.connect(self.DeletData)  
        self.ui.actionUpdate_data.triggered.connect(self.Update_Data) 
        self.label = self.ui.Label_SearchBy
        self.elem_for_search = False
        self.id_array = []
        self.ui.actionSearch_by_Nickname.triggered.connect(self.SearchByNickname)
        self.ui.actionSearc_by_Phone_number.triggered.connect(self.SearchByPhonenumber)
        self.ui.actionSearch_by_Surname.triggered.connect(self.SearchBySurname)
        self.ui.SearchBut.clicked.connect(self.Search)

    def OpenData(self):
        open_file_data = QtWidgets.QFileDialog.getOpenFileName(self, "Выбрать файл для открытия.", "C:/users/", '(*.csv)')
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setText("Загрузить данные в базу данных?")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
        returnValue = msgBox.exec()
        if returnValue == QtWidgets.QMessageBox.Ok:
            size_file = os.path.getsize(open_file_data[0])
            with open(open_file_data[0], 'r') as file:
                size = 0
                for i in range(100):
                    line = file.readline()
                    size += sys.getsizeof(line)

            whait = (size_file / size) * 100
            whait = int(whait) - 1
            p = QtWidgets.QProgressDialog(str("Загрузить данные в базу данных."), "Отмена", 0, whait)
            p.setMinimumDuration(0)
            with open(open_file_data[0], 'r') as log_file:
                j = 0
                for line in log_file:
                    p.setValue(j)
                    j += 1
                    QtWidgets.QApplication.processEvents()
                    k = line.split('|')
                    LoadData(coll, CreateDick(k[1], k[2], k[3], k[4], k[5], k[6], k[7]))
                    if p.wasCanceled():
                        break
                p.setValue(whait)

    def SearchByNickname(self):
        nickname, ok = QtWidgets.QInputDialog.getText(self, "Поиск по нику.", "Введите ник для поиска:",
                                                      QtWidgets.QLineEdit.Normal, '')
        if ok and nickname:
            self.label.setText("Поиск по нику: " + '\n' + nickname)
            self.elem_for_search = {'Nick': nickname}
            result = coll.find(self.elem_for_search)
            k = 0
            j = 0
            kratno100 = False
            self.ui.SplitBy100.clear()
            for i in result:
                kratno100 = False
                j += 1
                if ((j % 99) == 0):
                    k += 1
                    self.ui.SplitBy100.addItem("{0}-ые 100 элементов".format(k))
                    kratno100 = True
            self.ui.SplitBy100.setCurrentIndex(0)
            if kratno100:
                pass
            else:
                self.ui.SplitBy100.addItem("Остаток")
        elif ok and not nickname:
            QtWidgets.QMessageBox.about(self, 'Ошибка', "Пожалуйста, введите ник.")

    def SearchByPhonenumber(self):
        phone_num, ok = QtWidgets.QInputDialog.getText(self, "Поиск по номеру телефона.","Введите номер телефона для поиска:",
                                                       QtWidgets.QLineEdit.Normal, '')
        if ok and phone_num:
            self.label.setText("Поиск по номеру телефона: " + '\n' + phone_num)
            self.elem_for_search = {'Phone': phone_num}
            result = coll.find(self.elem_for_search)
            k = 0
            j = 0
            kratno100 = False
            self.ui.SplitBy100.clear()
            for i in result:
                kratno100 = False
                j += 1
                if ((j % 99) == 0):
                    k += 1
                    self.ui.SplitBy100.addItem("{0}-ые 100 элементов".format(k))
                    kratno100 = True
            self.ui.SplitBy100.setCurrentIndex(0)
            if kratno100:
                pass
            else:
                self.ui.SplitBy100.addItem("Остаток")
        elif ok and not phone_num:
            QtWidgets.QMessageBox.about(self, 'Ошибка', "Пожалуйста, введите номер телефона.")

    def SearchBySurname(self):
        surname, ok = QtWidgets.QInputDialog.getText(self, "Поиск по фамилии.", "Введите фамилию для поиска:",
                                                     QtWidgets.QLineEdit.Normal, '')
        if ok and surname:
            self.label.setText("Поиск по фамилии: " + '\n' + surname)
            self.elem_for_search = {'Surname': surname}
            result = coll.find(self.elem_for_search)
            k = 0
            j = 0
            kratno100 = False
            self.ui.SplitBy100.clear()
            for i in result:
                kratno100 = False
                j += 1
                if ((j % 99) == 0):
                    k += 1
                    self.ui.SplitBy100.addItem("{0}-ые 100 элементов".format(k))
                    kratno100 = True
            self.ui.SplitBy100.setCurrentIndex(0)
            if kratno100:
                pass
            else:
                self.ui.SplitBy100.addItem("Остаток")
        elif ok and not surname:
            QtWidgets.QMessageBox.about(self, 'Ошибка', "Пожалуйста, введите фамилию.")

    def Search(self):
        self.ui.actionSave_row.setDisabled(True)
        self.id_array = []
        if coll.estimated_document_count() == 0:
            QtWidgets.QMessageBox.about(self, 'Ошибка', "Эта база данных пустая.")
        else:
            if not self.elem_for_search:
                QtWidgets.QMessageBox.about(self, 'Ошибка', "Пожалуйста, введите параметр для поиска.")
            else:
                result = FoundData(coll, self.elem_for_search, self.ui.SplitBy100.currentIndex())
                self.ui.tableWidget.setRowCount(0)
                row_num = 0
                for dick in result:
                    self.ui.tableWidget.insertRow(self.ui.tableWidget.rowCount())
                    colum_num = 0
                    for key, value in dick.items():
                        if key == '_id':
                            self.id_array.append(value)
                            continue
                        it = QtWidgets.QTableWidgetItem()
                        it.setData(QtCore.Qt.DisplayRole, value)
                        self.ui.tableWidget.setItem(row_num, colum_num, it)
                        colum_num += 1
                    row_num += 1
                if row_num == 0:
                    QtWidgets.QMessageBox.about(self, 'Ошибка 404', "Данные не найдены.")

    def SaveData(self):
        if not self.elem_for_search:
            QtWidgets.QMessageBox.about(self, 'Ошибка', 'Нет поискового запроса.')
        else:
            save = QtWidgets.QFileDialog.getSaveFileName(self, "Выберете имя файла для сохранения", "/data_save",
                                                         "(*.json)")
            if save[0] == '':
                QtWidgets.QMessageBox.about(self, 'Ошибка', 'Вы отменили сохранение.')
            else:
                save_data = self.elem_for_search
                save_data['ComboBoxID'] = self.ui.SplitBy100.currentIndex()
                with open(save[0], 'w')as save_file:
                    json.dump(save_data, save_file)

    def LoadData(self):
        open_load_file = QtWidgets.QFileDialog.getOpenFileName(self, "Выберите файл для открытия.", "C:/users/",
                                                                '(*.json)')
        with open(open_load_file[0], 'r')as load_file:
            data = json.load(load_file)
        comboID = data['ComboBoxID']
        del data['ComboBoxID']
        name_file = os.path.basename(open_load_file[0])
        self.label.setText("Загрузить поисковый запрос из файла: " + '\n' + name_file)
        self.ui.SplitBy100.clear()
        result = FoundData(coll, data, comboID)
        self.ui.tableWidget.setRowCount(0)
        row_num = 0
        for dick in result:
            self.ui.tableWidget.insertRow(self.ui.tableWidget.rowCount())
            colum_num = 0
            for key, value in dick.items():
                if key == '_id':
                    continue
                it = QtWidgets.QTableWidgetItem()
                it.setData(QtCore.Qt.DisplayRole, value)
                self.ui.tableWidget.setItem(row_num, colum_num, it)
                colum_num += 1
            row_num += 1
        if row_num == 0:
            QtWidgets.QMessageBox.about(self, 'Ошибка 404', "Данные не найдены.")

    def ClearRow_forEnter(self):
        self.ui.actionSave_row.setDisabled(False)
        self.ui.tableWidget.setRowCount(0)
        self.ui.tableWidget.setRowCount(1)

    def SaveRow_inDB(self):
        data = []
        try:
            for i in range(7):
                data.append(self.ui.tableWidget.item(0, i).text())
        except AttributeError:
            QtWidgets.QMessageBox.about(self, 'Ошибка', 'Столбец ' + str(i + 1) + ' пустой')
            return 1
        LoadData(coll, CreateDick(data[0], data[1], data[2], data[3], data[4], data[5], data[6]))
        QtWidgets.QMessageBox.about(self, 'Завершено.', "Данные добавлены в базу данных.")
        self.ui.tableWidget.setRowCount(0)

    def DeletData(self):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setText("Вы уверены в том что хотите удалить данную строку")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
        returnValue = msgBox.exec()
        if returnValue == QtWidgets.QMessageBox.Ok:
            tabel = self.ui.tableWidget
            current_row = tabel.currentRow()
            id = {'_id': self.id_array[current_row]}
            if current_row == -1:
                QtWidgets.QMessageBox.about(self, 'Ошибка', "Строка невыбрана.")
                return 1
            tabel.removeRow(current_row)
            self.id_array.remove(self.id_array[current_row])
            DeleteData(coll, id)


    def Update_Data(self):
        tabel = self.ui.tableWidget
        current_row = tabel.currentRow()
        if current_row == -1:
            QtWidgets.QMessageBox.about(self, 'Ошибка', "Строка невыбрана.")
            return 1
        id = {'_id': self.id_array[current_row]}
        columMax = 7
        data_row = []
        for currentColum in range(columMax):
            data_row.append(tabel.item(current_row, currentColum).text())
        UpdateData(id, CreateDick(data_row[0], data_row[1], data_row[2], data_row[3], data_row[4], data_row[5],
                                  data_row[6]))


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyWin()
    myapp.show()
    sys.exit(app.exec_())
